﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Drawing
{
    public partial class Form1 : Form
    {
        Bitmap pict;
        Pen p;
        Graphics g;
        Rectangle rect;
        Point LocXY, LocX1Y;
        bool isMouseDown = false;
        bool isCircle, isRect, isLine, isPen;

        public Form1()
        {
            InitializeComponent();
            pict = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            p = new Pen(Color.Black, 3);
            g = Graphics.FromImage(pict);
            Pen_Click(null, null);
        }

        private void Circle_Click(object sender, EventArgs e)
        {
            isCircle = true;
            isLine = false;
            isRect = false;
            isPen = false;
        }

        private void Line_Click(object sender, EventArgs e)
        {
            isLine = true;
            isCircle = false;
            isRect = false;
            isPen = false;
        }

        private void Rectangle_Click(object sender, EventArgs e)
        {
            isRect = true;
            isLine = false;
            isCircle = false;
            isPen = false;
        }

        private void Pen_Click(object sender, EventArgs e)
        {
            isPen = true;
            isLine = false;
            isCircle = false;
            isRect = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            pictureBox1.BackColor = b.BackColor;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            p.Color = b.BackColor;
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            p.Width = float.Parse(Convert.ToString(numericUpDown1.Value));
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            //Size s = new Size(this.Width, this.Height - 71);
            //Bitmap newPict = pict;
            //pict = new Bitmap(this.Width, this.Height - 71);
            //g = Graphics.FromImage(pict);
            //pictureBox1.Width = this.Width;
            //pictureBox1.Height = this.Height;
            //pictureBox1.Image = newPict;


        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image files(*.bmp;*.jpg;*.png)|*.bmp;*.jpg;*.png";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    pictureBox1.BackgroundImage = new Bitmap(ofd.FileName);
                }
                catch
                {
                    MessageBox.Show("Erorr");
                }
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "BMP files(*.bmp)|*.bmp|JPG files(*.jpg)|*.jpg|PNG files(*.png)|*.png";
            sfd.OverwritePrompt = true;
            sfd.CheckPathExists = true;

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    pictureBox1.Image.Save(sfd.FileName);
                }
                catch
                {
                    MessageBox.Show("Erorr");
                }
            }
            //path = sfd.FileName;
            //if (path.IndexOf(".txt") == -1)
            //    richTextBox1.SaveFile(path, RichTextBoxStreamType.RichText);
            //else
            //    File.WriteAllText(path, richTextBox1.Text);
            //this.Text = sfd.FileName.Substring(sfd.FileName.LastIndexOf('\\') + 1);
        }

        private Rectangle GetRect()
        {
            rect = new Rectangle();
            rect.X = Math.Min(LocXY.X, LocX1Y.X);
            rect.Y = Math.Min(LocXY.Y, LocX1Y.Y);
            rect.Width = Math.Abs(LocXY.X - LocX1Y.X);
            rect.Height = Math.Abs(LocXY.Y - LocX1Y.Y);
            return rect;
        }
        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                LocX1Y = e.Location;
                if (isPen)
                {
                    p.StartCap = System.Drawing.Drawing2D.LineCap.Round;
                    p.EndCap = System.Drawing.Drawing2D.LineCap.Round;
                    g.DrawLine(p, LocXY, LocX1Y);
                    pictureBox1.Image = pict;
                    if (e.Button == MouseButtons.Left)
                    {
                        g.DrawLine(p, LocXY, LocX1Y);
                        pictureBox1.Image = pict;
                    }
                    LocXY = LocX1Y;
                }
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            isMouseDown = true;
            LocXY = e.Location;
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            LocX1Y = e.Location;
            isMouseDown = false;
            if (e.Button == MouseButtons.Left)
            {
                if (isLine)
                {
                    g.DrawLine(p, LocXY, LocX1Y);
                    pictureBox1.Image = pict;
                    LocXY = new Point();
                    LocX1Y = new Point();
                }
                if (isRect)
                {
                    g.DrawRectangle(p, GetRect());
                    pictureBox1.Image = pict;
                    LocXY = new Point();
                    LocX1Y = new Point();
                }
                if (isCircle)
                {
                    g.DrawEllipse(p, GetRect());
                    pictureBox1.Image = pict;
                    LocXY = new Point();
                    LocX1Y = new Point();
                }
            }
        }
    }
}
